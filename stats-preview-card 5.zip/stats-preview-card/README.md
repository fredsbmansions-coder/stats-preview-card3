# Stats Preview Card

A beginner-friendly HTML and CSS version of the Frontend Mentor Stats Preview Card challenge.

## Files
- `index.html` contains the page content.
- `style.css` contains the colors, layout, and mobile responsive styles.
- `images/team-photo.jpg` is the image used in the card.

## Run it
Open `index.html` in your browser. No installation is needed.

## Publish it
1. Create a new repository on GitHub.
2. Upload `index.html`, `style.css`, `README.md`, and the `images` folder.
3. On Vercel, choose **Add New → Project**, import the GitHub repository, and deploy it. This is a plain HTML/CSS site, so no build command is needed.
